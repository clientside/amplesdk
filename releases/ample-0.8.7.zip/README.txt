Ample SDK AJAX Application Framework

Ample SDK is a unique piece of software that runs transparently in the layer
between web browser and your application. While running it provides the Logic
of your application with standard cross-browser access to the User Interface.

The easiest way to get started is looking into examples folder and running
its examples/index.html from your browser. You may also reffer to the complete
reference by accessing documentation/reference/index.html from your browser.

http://www.amplesdk.com

If you would like to contact the authors send an email to inquiry@clientside.fi